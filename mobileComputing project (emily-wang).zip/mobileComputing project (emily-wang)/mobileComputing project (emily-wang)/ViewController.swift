//
//  ViewController.swift
//  mobileComputing project (emily-wang)
//
//  Created by Emily Wang on 10/24/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

